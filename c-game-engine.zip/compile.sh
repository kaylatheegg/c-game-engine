rm a.out
make -j8
./a.out