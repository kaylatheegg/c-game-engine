#pragma once
#define UI_H

#include "button.h"
#include "text.h"
#include "percentbar.h"
void initUI();