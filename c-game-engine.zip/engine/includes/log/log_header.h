#pragma once
#define LOG_HEADER_H

#include "log.h"
#include "init.h"