#pragma once
#define LOG_INIT_H

FILE *logptr;

int initLog();