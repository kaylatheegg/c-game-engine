#pragma once
#define ENTITY_H

#include "init.h"
#include "physics.h"
#include "entity.h"