#pragma once
#define INIT_MAIN_H

int running;

float dt;