#pragma once
#define INIT_HEADER_H

#include "main.h"
#include "crash.h"