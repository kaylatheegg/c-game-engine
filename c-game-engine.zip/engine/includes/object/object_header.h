#pragma once
#define OBJECT_HEADER_H

#include "init.h"
#include "object.h"