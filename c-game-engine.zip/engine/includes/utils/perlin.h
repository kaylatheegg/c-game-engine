#pragma once
#define UTILS_NOISE_H

float perlin2d(float x, float y, float freq, int depth);