#pragma once
#define UTILS_RANDOM_H

int randRange(int range);
vec randBox(int width, int height);