#pragma once
#define WORLD_H 

int generateWorld();
int loadStructure(char* filename, int x, int y);

