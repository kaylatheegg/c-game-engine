#pragma once
#define RENDER_HEADER_H

#include "init.h"
#include "render.h"
#include "texture.h"
#include "shapes.h"