# c-game-engine
my sdl2 game engine, on the fourth iteration 

its not the most powerful or well designed engine, but its a fun hobby and i love doing it :)

if you discover this outside of discord and want to talk about it w/ me, message me on discord
my username is kayla#2013

# DEPENDENCES

if you're on an aptitude based system, use the command below to get all dependencies

```bash
sudo apt-get install libsdl2-dev libsdl2-image-dev libglew-dev libfreetype6-dev build-essential git
```

# HOW TO BUILD

to build the engine, get the dependencies and then type into your terminal (linux and windows cc)

linux:
```bash
make build-linux
```
windows: (mingw required, modification of the makefile may be needed)
```bash
make build-windows
```


# OLD TEST IMAGES
THESE BELOW ARE OUTDATED, IGNORE!

first major stress test of object system
![first test of object system](https://cdn.discordapp.com/attachments/594212045621035030/791334671845556234/unknown.png)

first test of entity system here:
![idklol](https://cdn.discordapp.com/attachments/594212045621035030/801850454207627315/Peek_2021-01-21_16-26.gif)

demo that comes w/ the engine at the moment

![yes](https://cdn.discordapp.com/attachments/629715847266697256/806695739925069874/Peek_2021-02-04_01-20.gif)
